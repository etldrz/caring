ei++.o: ei++.cpp ei++.hpp \
  /Users/etldrz/.asdf/installs/erlang/28.1/lib/erl_interface-5.6.1/include/ei.h
