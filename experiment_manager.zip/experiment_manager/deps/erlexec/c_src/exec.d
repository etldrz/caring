exec.o: exec.cpp exec.hpp poll_handler.hpp ei++.hpp \
  /Users/etldrz/.asdf/installs/erlang/28.1/lib/erl_interface-5.6.1/include/ei.h
