defmodule Head do
  use GenServer

  # client
  def start_head() do
    GenServer.start_link(__MODULE__, %{}, name: :head)
  end

  def broadcast(fun, arg) do
    GenServer.call(:head, {:broadcast_fun, fun, arg})
  end

  def get_state() do
    GenServer.call(:head, :get_state)
  end

  # server
  @impl true
  def init(_) do
    initstate =
      %{
        head_init_time: Steward.current_time(),
        head_name: Node.self(),
        log: []
      }

    {:ok, initstate}
  end

  @impl true
  def handle_info({:ok, arm_name, arm_results}, state) do
    entry = %{
      results_received: arm_name,
      results: arm_results,
      timestamp: Steward.current_time()
    }

    {:noreply, Map.update!(state, :log, &(&1 ++ [entry]))}
  end

  @impl true
  def handle_call({:broadcast_fun, fun, arg}, _from, state) do
    entry =
      %{
        fun: fun,
        args: arg,
        sent_to: Node.list()
      }

    entry[:sent_to]
    |> Enum.each(fn node ->
      send({:arm, node}, {:fun_request, fun, arg, Node.self()})
    end)

    entry = %{entry_type: :broadcast_preformed, timestamp: Steward.current_time(), data: entry}
    {:reply, :ok, Map.update!(state, :log, &(&1 ++ [entry]))}
  end

  @impl true
  def handle_call(:get_state, _from, state) do
    {:reply, state, state}
  end
end
