defmodule Steward do
  use GenServer

  # client 

  def start_link({cmd, opts}) do
    GenServer.start_link(__MODULE__, {cmd, opts})
  end

  def stop(pid) do
    GenServer.stop(pid)
  end

  def run_command(pid) do
    # this returns ok even if the steward is down
    GenServer.cast(pid, :run)
  end

  def get_log(pid, send_to) do
    GenServer.call(pid, {:log_stream, send_to})
  end

  # server

  @impl true
  def init({cmd, opts}) do
    # put the cmd and options in here and then create a call to start the cmd. here
    # you can set up only running once
    state =
      %{
        cmd: cmd,
        opts: [:stdout, :stderr, :monitor] ++ opts,
        log: [[output: "steward initialized", timestamp: current_time()]],
        open_processes: [],
        finished?: false,
        running?: false
      }

    {:ok, state}

    # |> Map.put(:log, [[output: "steward initialized", timestamp: current_time()]])
    ## |> Map.put(:log, [output: "steward initialized", :cmd, cmd, timestamp: current_time()]])
    # |> Map.put(:open_processes, [])
    # |> Map.put(:finished?, false)
    # |> Map.put(:running?, false)
  end

  @impl true
  def handle_cast(:run, state) do
    :exec.run(state[:cmd], state[:opts])
    {:noreply, state}
  end

  @impl true
  def handle_cast({:update_processes, mesg}, state) do
    state[:open_processes] |> Enum.each(fn pid -> send(pid, mesg) end)
    # wipe open_processes if finished?
    {:noreply, state}
  end

  @impl true
  def handle_info({:stdout, ospid, output}, state) do
    entry = [source: :stdout, output: output, ospid: ospid, timestamp: current_time()]
    GenServer.cast(self(), {:update_processes, [entry]})
    # {:noreply, Map.update!(state, :log, &(&1 ++ state[:open_processes]))}
    {:noreply, Map.update!(state, :log, &(&1 ++ [entry]))}
  end

  @impl true
  def handle_info({:stderr, ospid, output}, state) do
    entry = [source: :stderr, output: output, ospid: ospid, timestamp: current_time()]
    GenServer.cast(self(), {:update_processes, [entry]})
    {:noreply, Map.update!(state, :log, &(&1 ++ [entry]))}
  end

  @impl true
  def handle_info({:DOWN, ospid, :process, _pid, :normal}, state) do
    entry = [
      output: "process exited normally",
      ospid: ospid,
      timestamp: current_time()
    ]

    new_state =
      state
      |> Map.update!(:finished?, fn _oldvar -> true end)
      |> Map.update!(
        :log,
        &(&1 ++ [[entry], [output: "steward ended", timestamp: current_time()], :ok])
      )

    GenServer.cast(self(), {:update_processes, {entry, :ok}})
    {:noreply, new_state}
  end

  @impl true
  def handle_info({:DOWN, ospid, :process, _pid, {:exit_status, exit_status}}, state) do
    entry = [
      output: "process exited with exit status #{exit_status}",
      ospid: ospid,
      timestamp: current_time()
    ]

    new_state =
      state
      |> Map.update!(:finished?, fn _oldvar -> true end)
      |> Map.update!(
        :log,
        &(&1 ++ [[entry], [output: "steward ended", timestamp: current_time()], :error])
      )

    GenServer.cast(self(), {:update_processes, {entry, :error}})
    {:noreply, new_state}
  end

  @impl true
  def handle_call({:log_stream, output_pid}, _from, state) do
    if state[:finished?] do
      {:reply, state[:log], state}
    else
      # task = Task.async(fn -> log_stream(state[:log]) end)
      # stream = Task.await(task)
      new_state = Map.update!(state, :open_processes, &[output_pid | &1])
      {:reply, log_stream(state[:log]), new_state}
    end
  end

  # helper funs

  # this does not receive messages when any process other than the original calling process
  # accesses it
  defp log_stream(log) do
    Stream.resource(
      fn -> log end,
      fn log ->
        case log do
          :done ->
            {:halt, []}

          [] ->
            receive do
              {item, :ok} -> {[item, :ok], :done}
              {item, :error} -> {[item, :error], :done}
              resp -> {resp, []}
            end

          items ->
            {items, []}
        end
      end,
      fn _ -> :ok end
    )
  end

  def current_time() do
    Time.utc_now() |> Time.to_iso8601()
  end
end
